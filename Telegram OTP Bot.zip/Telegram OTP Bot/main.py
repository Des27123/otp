import os
import telebot
from telebot.types import (
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    ReplyKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardRemove,
)
from dotenv import load_dotenv

load_dotenv()

bot = telebot.TeleBot(os.environ.get("BOT_TOKEN"), threaded=False)
bot.remove_webhook()

START_MESSAGE = "☎️ OTP Subscription Prices ☎️\n\n7 Days | $80\n15 Days | $150\n30 Days | $270 🚨 Promo\n90 Days | $700\nLifetime | $1000\n\n🔱 Otp Bot Features 🔱\n\n■ CALLER ID SPOOFER\n■ OTP CODE BYPASS\n■ ANY 2FA BYPASS\n■ 3D SECURE BYPASS\n■ +70 READY SCRIPT (BANK OF AMERICA, AMEX, VUTTON BANK, DISCOVER BANK ETC.)\n■ +40 READY SCRIPT (CHASE,PAYPAL,APPLE PAY, WELLS FARGO, CASHAPP ETC.)\n■ CVV CODE RECEİVE\n■ CC STEALER (WITH PIN OPTION)\n■ PGP & DPGP MODE \n\n📁 Owner: @otpdev\n\n☑️ Select your package from the menu and Purchase Membership with Auto Crypto Payment System."
WELCOME_OTP_BOT = "💻 🔹️ Spooky OTP BOT 💻 🔹️\n\n📞 Welcome to Spooky OTP BOT, we’ve created this section for you to understand the features provided which will differentiate us from the rest & which you can use to better your craft.\n\n🧬 ALL MODES;\n⁃ Banks 🏦\n⁃ Pay Mode (Apple Pay, Google Pay, Chase, Paypal… Etc) 🍏\n⁃ Carrier 📞 \n⁃ Email 📧\n⁃ Stores 🛒\n⁃ Crypto Mode (Coinbase… Etc) 🤩\n⁃ PGP MODE 📱\n⁃ Spoof Panel (Capture Fullz) 🔥 \n⁃ Social (Snapchat Etc…)  👨‍👨‍👧‍👦\n⁃ Cloud (Drive, iCloud ☁️)\n\nPGP MODE ( 🇺🇸 🇬🇧 🇨🇦)\nHighest Speed PGP MODE User friendly bot is a reliable source to spoof any number from the countries above (UK, USA, CANADA). 💨⚡️\n\nWhat is the reason you may consider using PGP MODE?\n\n🧬 With our bot you will be able to impersonate either a service or an individual directly with the victim. 💨⚡️\n\nWhat happens if victim does not hand over OTP First Time?\n\n🧬 You are able to Prompt OTP, 2FA multiple times, reason being victim could make mistake and ending call before making sure this is correct, could mean you miss a vital hit This is something we have taken into consideration. 📟\n\nSpoof Panel 💻 📟\n\n🧬 Spoof Panel gives you an alternative to solely just the usual OTP some may be looking for. You’ll now be able to capture\n\n🧬 FULL CC 💳 DIGITS , EXPIRY, ID 🪪 ,2FA\n🔹️ ZIP, DOB, SSN, ATM PIN, OTP 💻. (Currently these are the options as you’ve figured are numerical value, we will shortly be working on a way to work on bringing text).  💨⚡️\n\nThis Feature is included for all members upon purchase at no additional cost 🔥.\nMay I add this cab also be toggled on/off if not necessary. Same as our PhishText feature. 💨⚡️\n\nPhishText 💬\n🔹️ This is a feature believed to be able to increase your success rate, the reason being for this is our system allows the victim to know they are going to receive a call (via text) prior to calling."
BOT_COMMANDS = "SPOOKY OTP Bot Command List\n─═──═──═──═──═──═─\n\nOTP 📱\nUse this to get an OTP Code from victim, digits may vary on company\n/call +123456789 otp Robert-James 6 Paypal\n\nPIN 🔗\nUse this to get a PIN codes from your victim\n/call +123456789 pin Robert-James 4 Bank-of-America\n\nCVV 💳\nUse this to get 3 digits code on your victim credit card\n/call +123456789 cvv Robert-James 3 Amazon 5432\n\nAuthenticator 🔒 \nUse this to get a 6 Digits code from your victim Authenticator Application\n/call +123456789 auth Robert-James 6 Coinbase\n\nCustom  Use this to generate your own script, customizeable on how you want to use our bot\n/call +123456789 custom Robert-James 6 Paypal scriptname\n\nAfter purchasing and activating your membership, you can use the commands below and bypass otp as you wish.\n\nUse /script to list all of your available script\nUse /createscript name to create your own script\nUse /readscript name to read the summary of your script\nUse /removescript name to remove a script\n\n❗️ONLY MEMBERS CAN USE COMMANDS ☑️"
NO_ACCESS = "❌ 𝗬𝗼𝘂 𝗵𝗮𝘃𝗲 𝗻𝗼 𝗮𝗰𝗰𝗲𝘀𝘀 ❌\n\n═══════════════════\n💰 𝗬𝗼𝘂 𝗰𝗮𝗻 𝗯𝘂𝘆 𝗮 𝘀𝘂𝗯𝘀𝗰𝗿𝗶𝗽𝘁𝗶𝗼𝗻 𝗯𝗲𝗹𝗼𝘄 \n═══════════════════\n"
FAQ = "♦☎ SPOOKY BOT ♦☎\n\nWelcome to our very own FAQ, if you have no relative experience for otp bot or this is your first time using a OTP BOT system,\nThis section will come in useful.\n\n- What is the purpose of an OTP BOT? \n\nWith Otp Bot, you can steal the codes sent to your victim's phone. Any otp & 2fa & 3d secure & pin code otp bot steals from the victim through social engineering. With Spoofer, it spoofs a bank number or company number and your victim has no idea what's going on.\n\n- Can I call every country with your bot? \n\nYes, you can call any country. We use deepL API for language translation in our system (Much better than Google Translate). 3 different call services are included in our system to make global call (twilio,plivo,telynx). In other words, you can call any country you want in any language and bypass OTP.\n\n- How do I purchase and activate OTP Bot membership?\n\nFirst of all, you can automatically get your membership by choosing the period you want with the automatic payment system on the bot and paying to the specified crypto address. (The system automatically checks, detects and approves the payments.)\n\nAlternatively, you can purchase it by contacting @otpdev (the owner of the bot) and making a payment. He gives you an activation key and you enter it in the license key field on the bot and activate your membership yourself."
ENTER_LICENSE_KEY = "🔑 Please Enter Your Subscription License Key:"
MODULES = "Available Modules\n📞 Call - based on Telnyx\n☎️ Call V2 - based on Plivo\n📲 Call V3 - based on Twilio\n📧 SMS - Steal Sms Codes"
CONTACT_OWNER = "❗️This Area For Contacting the Owner, For Issues & Questions & Help.\n\nPlease Don't Make a Spam"

BTC_ADDRESS = "195zF7EPQFsT9ZzpdgidFdKwGCVAAHr2DK"
ETH_ADDRESS = "0x65ec758328e333d3edb7314617d930a563428d2a"
LTC_ADDRESS = "LLmtqAwexWxs16Th3SqP2bVzQrNiQZ38kx"
USDT_TRON20_ADDRESS = "TAsoYJaw1WQwnqHkvUDA952zWsKt6mu9jy"

steps = {}
STEP_ENTER_VICTIM_NUM = "vic_num"
STEP_ENTER_VICTIM_NAME = "vic_name"
STEP_BUY = "vic_buy"
STEP_CONTACT = "cont"
STEP_ENTER_LICENSE = "lic"

# Replace this with video file if you want to send video over image. Make sure you comment code #1 and uncomment code #2
File = "banner.jpg"


@bot.message_handler(commands=["start", "help"])
def welcome(message):
    markup = ReplyKeyboardMarkup()
    btn1 = KeyboardButton("☎ Make a Call")
    btn2 = KeyboardButton("💁 Features")
    btn3 = KeyboardButton("🛍 Purchase")
    btn4 = KeyboardButton("🫵 My Membership")
    btn5 = KeyboardButton("🎫 Enter License Key")
    btn6 = KeyboardButton("💬 FAQ")
    btn7 = KeyboardButton("📝 How to Use ?")
    btn8 = KeyboardButton("🤙 Contact")

    markup.row(btn1)
    markup.row(btn2, btn3)
    markup.row(btn4, btn5)
    markup.row(btn6)
    markup.row(btn7)
    markup.row(btn8)

    banner = open(File, "rb")

    if File.contains(".gif"):
        bot.send_animation(message.chat.id, banner, caption=START_MESSAGE, reply_markup=markup)
    else:
        bot.send_photo(message.chat.id, banner, caption=START_MESSAGE, reply_markup=markup)

    banner.close()


cancel_markup = ReplyKeyboardMarkup(row_width=1, resize_keyboard=True)
cancel_button = KeyboardButton("🚫 Cancel")
cancel_markup.add(cancel_button)


@bot.message_handler(
    commands=["call", "script", "createscript", "readscript", "removescript"]
)
def handle_command(message):
    handle_purchase(message)


@bot.message_handler(func=lambda message: message.text == "☎ Make a Call")
def handle_make_call(message):
    bot.send_message(
        message.chat.id, "Enter the victim number:", reply_markup=cancel_markup
    )


@bot.message_handler(func=lambda message: message.text == "🤙 Contact")
def handle_contact(message):
    bot.send_message(
        message.chat.id,
        text=CONTACT_OWNER,
        reply_markup=cancel_markup,
    )
    bot.send_message(message.chat.id, "📨 Your Message:", reply_markup=cancel_markup)
    steps[message.message.from_user.id] = STEP_CONTACT


@bot.message_handler(func=lambda message: message.text == "💁 Features")
def handle_features(message):
    bot.send_message(message.chat.id, MODULES)
    bot.send_message(message.chat.id, WELCOME_OTP_BOT)


@bot.message_handler(func=lambda message: message.text == "🎫 Enter License Key")
def handle_license(message):
    bot.send_message(message.chat.id, ENTER_LICENSE_KEY, reply_markup=cancel_markup)
    steps[message.from_user.id] = STEP_ENTER_LICENSE


@bot.message_handler(func=lambda message: message.text == "🫵 My Membership")
def handle_membership(message):
    username = message.from_user.username
    userid = message.from_user.id
    fetch_details = bot.send_message(
        message.chat.id, text="Fetching details from database ..."
    )

    bot.edit_message_text(
        text=f"\n🔥𝗨𝘀𝗲𝗿: @{username}\n🔥𝗡𝘂𝗺𝗯𝗲𝗿 𝗼𝗳 𝗽𝘂𝗿𝗰𝗵𝗮𝘀𝗲𝘀: 0\n🔥𝗨𝘀𝗲𝗿 𝗜𝗗: {userid}\n🔥𝗬𝗼𝘂𝗿 𝗯𝗮𝗹𝗮𝗻𝗰𝗲: 𝟬 $\n",
        chat_id=message.chat.id,
        message_id=fetch_details.message_id,
    )


@bot.message_handler(func=lambda message: message.text == "💬 FAQ")
def handle_features(message):
    bot.send_message(message.chat.id, FAQ)


@bot.message_handler(func=lambda message: message.text == "🛍 Purchase")
def handle_purchase(message):
    price_markup = InlineKeyboardMarkup()
    button1 = InlineKeyboardButton("🛍 1 Day - $35", callback_data="purchase-35")
    button2 = InlineKeyboardButton("🛍 1 Week - $60", callback_data="purchase-60")
    button3 = InlineKeyboardButton("🛍 1 Month - $100", callback_data="purchase-100")
    button4 = InlineKeyboardButton("🛍 Lifetime - $200", callback_data="purchase-200")

    price_markup.max_row_keys = 1
    price_markup.row(button1, button2, button3, button4)

    bot.send_message(
        message.chat.id,
        text=NO_ACCESS,
        reply_markup=price_markup,
    )


@bot.message_handler(func=lambda message: message.text == "📝 How to Use ?")
def handle_faq(message):
    bot.send_message(message.chat.id, BOT_COMMANDS)


@bot.message_handler(func=lambda message: True)
def handle_text_message(message):
    user_id = message.from_user.id
    step = steps.get(user_id, STEP_ENTER_VICTIM_NUM)

    if message.text.lower() == "🚫 cancel":
        bot.send_message(
            message.chat.id, "Operation cancelled.", reply_markup=ReplyKeyboardRemove()
        )
        if user_id in steps.keys():
            del steps[user_id]
        welcome(message)

    elif step == STEP_ENTER_VICTIM_NUM:
        if not is_number(message.text):
            bot.send_message(message.chat.id, "Please enter a valid number ❌")
            welcome(message)
            steps[user_id] = STEP_ENTER_VICTIM_NUM

        elif is_number(message.text) and len(message.text) > 9:
            bot.send_message(
                message.chat.id, "Enter Victim Name: ", reply_markup=cancel_markup
            )
            steps[user_id] = STEP_BUY
        elif len(message.text) < 9:
            bot.send_message(
                message.chat.id,
                "Number you have entered is incorrect ❌",
                reply_markup=cancel_markup,
            )
            handle_make_call(message)
            steps[user_id] = STEP_ENTER_VICTIM_NUM

    elif step == STEP_ENTER_VICTIM_NAME:
        bot.send_message(
            message.chat.id, "Enter Victim Name: ", reply_markup=cancel_markup
        )
    elif step == STEP_ENTER_LICENSE:
        bot.send_message(
            message.chat.id,
            "Please Enter Valid License Key ❌",
            reply_markup=cancel_markup,
        )
        handle_license(message)

    elif step == STEP_CONTACT:
        bot.send_message(
            message.chat.id,
            "Your Message has successfully send to the owner ✅",
            reply_markup=cancel_markup,
        )

    elif step == STEP_BUY:
        handle_purchase(message)


@bot.callback_query_handler(func=lambda call: True)
def callback_query(call):
    username = call.message.from_user.username
    userid = call.message.from_user.id
    chat_id = call.message.chat.id
    message_id = call.message.id

    suffix = f"▫️ Voucher Duration: 1 Month\n\nPAYMENT METHOD \nInstant Confirmation\n\n▫️ Bitcoin (BTC): {BTC_ADDRESS}\n\n▫️ USDT (Trc20): {USDT_TRON20_ADDRESS}\n\n▫️ LTC : {LTC_ADDRESS}\n\nPlease wait for your payment to be automatically confirmed. It will be confirmed in no more than 20 minutes.\n\nIf still not confirmed, send the txid or screenshot to admin: @otpdev"
    if call.data == "purchase-35":
        bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=f"INVOICE DETAILS\n\n▫️ Total Payment: USD 35\n{suffix}",
        )
    elif call.data == "purchase-60":
        bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=f"INVOICE DETAILS\n\n▫️ Total Payment: USD 60\n{suffix}",
        )
    elif call.data == "purchase-100":
        bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=f"INVOICE DETAILS\n\n▫️ Total Payment: USD 100\n{suffix}",
        )
    elif call.data == "purchase-200":
        bot.edit_message_text(
            chat_id=chat_id,
            message_id=message_id,
            text=f"INVOICE DETAILS\n\n▫️ Total Payment: USD 200\n▫️ Voucher Duration: 1 Month\n\nPAYMENT METHOD \nInstant Confirmation\n\n▫️ Bitcoin (BTC): {BTC_ADDRESS}\n\n▫️ USDT (Trc20): {USDT_TRON20_ADDRESS}\n\n▫️ LTC : {LTC_ADDRESS}\n\nPlease wait for your payment to be automatically confirmed. It will be confirmed in no more than 20 minutes.\n\nIf still not confirmed, send the txid or screenshot to admin: @otpdev",
        )
    bot.send_message(
        chat_id,
        "▶️ When the payment is completed, license key will be sent to you automatically. You must enter the code you receive into the license key section on the bot and activate your membership ☑️",
    )
    bot.send_message(chat_id, "🔹 PAYMENT STILL WAITING CONFIRMATION... ⏳")


def is_number(text):
    try:
        int(text)
        return True
    except ValueError:
        return False


bot.infinity_polling()
